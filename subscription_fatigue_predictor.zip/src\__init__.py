"""
Subscription Fatigue Predictor - Data Science Package
"""

__version__ = "1.0.0"
__author__ = "Data Science Team"
__description__ = "Analyze subscription pricing patterns and predict market saturation"
